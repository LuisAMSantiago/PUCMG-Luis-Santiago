using System;

class Program
{
    public static void Main(string[] args)
    {
        int N = 0, P = 0, M = 0, i = 0, numP = 0, numM = 0;
        string T;
        N = int.Parse(Console.ReadLine());
        T = Console.ReadLine();
        P = int.Parse(Console.ReadLine());
        M = int.Parse(Console.ReadLine()); 
        int lenght = T.Length;
        for (i = 0; i <  lenght; i++)
        {
            if (T[i] == ' ') continue;
            if (T[i] == '1') numP++;
            else numM++;
        }
        if (numP == P && numM == M)
            Console.Write("S");
        else Console.Write("N");
    }
}