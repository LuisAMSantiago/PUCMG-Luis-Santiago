#include <stdio.h>
#include <math.h>

int main(void) {
  int menor10,entre10e20,maior20,breaker;
  float pcompra,pvenda,porcecompra,porcevenda;
  pvenda=0;
  breaker=0;
  menor10=0;
  entre10e20=0;
  pcompra=1;
  maior20=0;
  while(breaker==0){
  printf("Insira o preço de compra e o preço de venda da mercadoria, inserindo preço de compra e de venda 0(zero) quando quiser encerrar o processo:\n");
    //aqui, diferente da questão que pede apenas um preço de compra de 0, eu pedi o preçode compra e de venda, pois se o usuário inserir apenas 1 valor, o scanf abaixo vai esperar a inserção do segundo valor para poder ir para o if que testa se o valor de compra é 0. Então para contornar a necessidade de fazer um código com um printf e um scanf extras antes do while, eu apenas pedi que ambos os valores fossem 0.
    scanf("%f %f",&pcompra,&pvenda);
    if(pcompra==0){
      breaker++;
    }else if(pvenda<(pcompra+(pcompra/10))){
      menor10++;
    }else if(pvenda>=(pcompra+(pcompra/10)) && pvenda<=(pcompra+(pcompra/5))){
      entre10e20++;
    }else if(pvenda>(pcompra+(pcompra/5))){
      //aqui eu utilizei else if pois eu considero que elses if (que são mais precisos que elses) são mais fáceis de entender.
      maior20++;
    }
    }
  printf("Um total de %d produtos oferecem lucro menor que 10 por cento.\nUm total de %d produtos oferecem lucro entre 10 e 20 por cento.\nUm total de %d produtos oferecem lucro maior que 20 por cento.",menor10,entre10e20,maior20);
  }