#include <stdio.h>
#include <math.h>

int main(void) {
  int n;
  float s,a;
  printf("Insira um valor inteiro para o cálculo:\n");
  scanf("%d",&n);
  a=1;
  s=1;
  printf("Termos:\n");
  while(a<(n+1)){
    //esse while eu utilizei para contar quantos e quais são os termos do cálculo solicitado, além de fazer o cálculo em si, que pode ser visto na linha de baixo. 
    s+=(1/a);
    printf("1/%.0f\n",a);
      a++;
    }
  printf("S=%f",s);
  }