#include <stdio.h>
#include <math.h>

int main(void) {
  int L,a,b,c;
  printf("Insira um valor para o cálculo\n");
  scanf("%d",&L);
  a=0;
  b=1;
  c=0;
  while(c<L){
    c=a+b;
    printf("%d ",b);
    //esse printf imprime o b e não o c, que é o resultado da conta, pois se imprimisse o c, iria imprimir um valor a mais do que o solicitado (todos os valores da sequência de fibonacci que sejam menores que o valor inserido), pois ele imprimiria o valor àcima antes do while detectar que o próximo valor seria maior que o valor inserido no console.
    a=b;
    b=c;
  }
  }