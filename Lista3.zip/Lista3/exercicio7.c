#include <stdio.h>
#include <math.h>

int main(void) {
  int L,fibo=1,a,b,c;
  printf("Insira um valor para o cálculo\n");
  scanf("%d",&L);
  a=0;
  b=1;
  c=0;
  printf("%d ",b);
  while(fibo<=L-1){
    //como dito antes, eu prefiro usar while quando só preciso de uma condição para o loop, enquanto o for pede 3 informações.
    c=a+b;
    a=b;
    b=c;
    printf("%d ",c);
    fibo++;
  }
  }