#include <stdio.h>
#include <math.h>

int main(void) {
  int variaveis,a,div3e9,div2,div5,naodiv;
  printf("Insira dez valores inteiros:\n");
  variaveis=1;
  div3e9=0;
  div2=0;
  div5=0;
  naodiv=0;
  while (variaveis<=10) {
    //aqui eu usei while pois ele se repete enquanto o parâmetro utilizado for verdadeiro.
    scanf ("%d",&a);
    if(a%3==0 && a%9==0){
      div3e9++;
      }
    if(a%2==0){
      div2++;
      }
    if(a%5==0){
      //acima eu usei vários ifs independentes, pois um mesmo número pode ser divisível tanto por 3 e 9 quanto por 2, etc
      div5++;
      }else if (a%9!=0 && a%2!=0 && a%5!=0){
      //aqui eu usei else if ao invés de else porque apesar de dar no mesmo, eu costumo preferir deixar esse tipo de sequência mais fácil de se entender desse jeito, com tudo definido com exatidão.
      naodiv++;
      }
    variaveis++;
    }
  if (naodiv>0){
    //esse if acima serve pra dar uma resposta em casos que existe algum valor inserido no console que não é divisível por nenhum dos valores
    printf("Dos 10 números inseridos, %d são divisíveis por 3 e 9, %d são divisíveis por 2, %d são divisíveis por 5, e %d números não são divisíveis por nenhum dos valores.",div3e9,div2,div5,naodiv);
  }else {
    //enquanto esse else esrve pra dar uma resposta em casos que não existe nenhum valor inserido no console que não seja divisível por nenhum dos valores
  printf("Dos 10 números inseridos, %d são divisíveis por 3 e 9, %d são divisíveis por 2, e %d são divisíveis por 5.",div3e9,div2,div5);
    }
  return 0;
}