#include <stdio.h>
#include <math.h>

int main(void) {
  int quantidade,variaveis,a,positivos,negativos,zeros;
  float porcentagemN,porcentagemP,porcentagemZ;
  printf("Digite quantos valores inteiros você pretende inserir, e depois insira um ou mais valores inteiros (na mesma linha, separados por espaço)\n");
  scanf("%d",&quantidade);
  variaveis=0;
  positivos=0;
  negativos=0;
  zeros=0;
  while (variaveis<quantidade){
    //aqui eu usei while pois ele se repete enquanto o parâmetro utilizado for verdadeiro.
    scanf("%d",&a);
    if(a<0){
      negativos++;
    }else if (a==0){
      zeros++;
    }else if (a>0){
      //aqui eu usei else if ao invés de else porque apesar de dar no mesmo, eu costumo preferir deixar esse tipo de sequência mais fácil de se entender desse jeito, com tudo definido com exatidão.
      positivos++;
    }
    variaveis++;
  }
  porcentagemP=(float)(positivos*100)/quantidade;
  porcentagemN=(float)(negativos*100)/quantidade;
  porcentagemZ=(float)(zeros*100)/quantidade;
  printf("O número de zeros equivale à %.2f por cento do total,  número de positivos equivale à %.2f por cento do total, e o número de negativos equivale à %.2f por cento do total.",porcentagemZ,porcentagemP,porcentagemN);
  return 0;
}