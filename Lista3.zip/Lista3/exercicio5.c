#include <stdio.h>
#include <math.h>

int main (void){
  int salarios,filhos,pessoas,pessoasate100,somafilhos,breaker;
  float salario,somasalarios,mediasalarios,mediafilhos,maiorsalario,porcentagemsalarios100;
  breaker=0;
  //essa variável breaker é o que eu criei para servir como um "interruptor" para o while, assim quando nenhuma das informações inseridas no console bater com o que eu preciso, o breaker++ "vira o interruptor" e encerra o while, assim permitindo que eu não precise de um printf e scanf fora do while para conseguir o meu primeiro valor.
  pessoas=0;
  maiorsalario=0;
  pessoasate100=0;
  somafilhos=0;
  somasalarios=0;
  while(breaker<=0){
  printf("Insira respectivamente um salário e o número de filhos (Exemplo: 400 2),inserindo um salário negativo quando desejar encerrar:\n");
  scanf("%f",&salario);
  if(salario>=0){
    scanf ("%d",&filhos);
    if(salario>maiorsalario){
      maiorsalario=salario;
    }
    if(salario<=100){
      pessoasate100++;
    }
    somasalarios+=salario;
    somafilhos+=filhos;
    pessoas++;
    }else if(salario<0){
    //esse else if é aonde o código descobre se o "interruptor" deve ser virado ou não.
      breaker++;
    }
    }
  mediasalarios=somasalarios/(float)pessoas;
  mediafilhos=somafilhos/(float)pessoas;
  porcentagemsalarios100=((float)pessoasate100*100)/(float)pessoas;
  //aqui eu usei esse monte de floats para que os resultados dos cálculos fossem em decimal, pois eu queria uma precisão maior nos resultados.
  printf("A média do salário da população é de R$%.2f\nA média do número de filhos da população é de %.2f filhos\nO maior salário é de R$%.2f\nUm total de %.2f por cento da população tem um salário menor que R$100,00.",mediasalarios,mediafilhos,maiorsalario,porcentagemsalarios100);
  return 0;
  }