#include <stdio.h>
#include <math.h>

int main(void) {
  int voto,breaker=0,votos1=0,votos2=0,votos3=0,votos4=0,votos5=0,votos6=0;
  
  while(breaker==0){
    printf("Insira o voto(1,2,3,4 = respectivos candidatos, 5= nulo, 6= em branco), inserindo voto 0(zero) quando quiser encerrar o processo:\n");
    scanf("%d",&voto);
    if(voto==0){
      breaker++;
      }else if(voto==1){
      votos1++;
      }else if(voto==2){
      votos2++;
      }else if(voto==3){
      votos3++;
      }else if(voto==4){
      votos4++;
      }else if(voto==5){
      votos5++;
      }else if(voto==6){
      //acima eu usei vários else ifs, mas esse último em específico, eu precisei usar no lugar de apenas else, só para que o usuário não receba votos nulos caso inserisse valores maiores que 5.
      votos6++;
      }
    }
  printf("Total de votos para o candidato 1: %d\nTotal de votos para o candidato 2: %d\nTotal de votos para o candidato 3: %d\nTotal de votos para o candidato 4: %d\nTotal de votos nulos: %d\nTotal de votos em branco: %d",votos1,votos2,votos3,votos4,votos5,votos6);
  }