#include <stdio.h>
#include <math.h>

float fatorialF (int n){
  //esse float é uma função usada pra definir o valor da variável result, para ser usada em cálculos seguintes.
  float result=1;
  for (int i=1; i<=n; i++){
    result*=i;
    }
  return result;
  }
float calculaSequencia(int n){
  //já esse float é uma função que chama a função fatorialF e recebe seu resultado, o fatorial de n, utilizando-o para calcular o valor do cálculo pedido na questão.
  float resultado=0;
  int cont=0;

  while (cont<n){
    //esse while é o que faz o cálculo pedido na questão, utilizando o valor do fatorial de n, que foi puxado pelo float calculaSequencia.
    if(cont==0)
      resultado=1;
    else
      //aqui eu usei else e não else if pois seria impossível definir um valor fixo para o else if utilizar, já que a função muda o valor da variável resultado o tempo todo.
      resultado+=(1/fatorialF(cont));
    cont++;
    }
  return resultado;
  }

int main(void) {
  int n=0;
  printf("Escreva um número inteiro positivo: \n");
  scanf("%i", &n);
  printf ("O E vale: %.2f", calculaSequencia(n));
  return 0;
  }