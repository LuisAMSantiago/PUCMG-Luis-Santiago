#include <stdio.h>

float calculaPotencia(int N){
  int denominador=4;
  while(N>0){
    fatorial*=N;
    N--;
    }
  return fatorial;
}

float calculaS(int N){
  float S=1;
  while(N>0){
  S=((N*N)(1/calculaFat(N));
    N--;
    }
  return S;
}

int main(){
  int N=0;
  printf("Insira seu valor N:\n");
  scanf("%d",&N);
  printf("seu valor S é %.5f",calculaS(N));
}
*/