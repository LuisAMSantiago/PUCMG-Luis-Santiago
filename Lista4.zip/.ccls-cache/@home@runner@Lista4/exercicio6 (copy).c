#include <stdio.h>

float fatorialF (int n){
  float result=1;
  for (int i=1; i<=n; i++){
    result*=i;
    }
  return result;
  }

float calculaSequencia(int n){
  float resultado=0;
  int cont=0;
  while (cont<n){
    if(cont==0)
      resultado=1;
    else
      resultado+=(1/fatorialF(cont));
    cont++;
    }
  return resultado;
  }

int main(void) {
  int N=0;
  printf("Insira o seu valor N:\n");
  scanf("%d", &N);
  printf ("O S vale: %.2f", calculaSequencia(n));
  return 0;
  }