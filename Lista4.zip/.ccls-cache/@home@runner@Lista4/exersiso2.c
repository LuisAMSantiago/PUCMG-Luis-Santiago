#include <stdio.h>

float media(float salario,int numsalarios,float somasalarios,int flag){
  float mediaR=0;
  if(flag==0){
  mediaR=somasalarios/numsalarios;
  printf("A média dos salários é de R$%.2f\n",mediaR);
    }
  return 0;
}

int main (){
  float somasalarios=0,salario=0,result=0;
  int numsalarios=0,flag=0;
  printf("Insira quantos salários serão utilizados no cálculo:\n");
    scanf("%d",&numsalarios);
  flag=numsalarios;
  while (flag>0){
    flag--;
    printf("Insira um salário:\n");
    scanf("%f",&salario);
    somasalarios+=salario;
    
  }
  result=media(salario,numsalarios,somasalarios,flag);
  flag--;
  }