/*
#include <stdio.h>

void veriftriangulo(float lado1, float lado2, float lado3){
  if(lado1>0 && lado2>0 && lado3>0){
  if(lado1==lado2 || lado1==lado3){
    if (lado2==lado3){
      printf("Seu triângulo é Equilátero!\n\n");
    }else if (lado2!=lado3){
      printf("Seu triângulo é Isóceles!\n\n");
    }
  }else if(lado2==lado3){
    printf("Seu triângulo é Isóceles!\n\n");
  }else if(lado1!=lado2 && lado2!=lado3 && lado1!=lado3){
    printf("Seu triângulo é Escaleno!\n\n");
  }
}else if (lado1<0|| lado2<0 ||lado3<0){
    printf("Um dos valores inseridos é inválido!\n\n");
  }else printf("Obrigado!\n\n");
  }

int main(){
  int flag=0;
  float lado1,lado2,lado3;
  while (flag==0){
    printf("Insira os três valores reais dos lados do triângulo(insira valor 0 para os 3 lados para encerrar):\n");
    scanf("%f %f %f",&lado1,&lado2,&lado3);
  if(lado1==0 || lado2==0 || lado3==0){
      flag++;
    }
    veriftriangulo(lado1,lado2,lado3);
    }
  return 0;
}
*/