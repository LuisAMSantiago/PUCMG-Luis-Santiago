/*
#include <stdio.h>

double medias(int nota1, int nota2, int nota3, char media){
double mediaR=0;
  if (media=='A'){
    mediaR=(nota1+nota2+nota3)/3.0;
    }else if (media=='P'){
    mediaR=((nota1*5)+(nota2*3)+nota3*2)/10.0;
    }
  return mediaR;
  }

int main(void){
  int N,nota1,nota2,nota3;
  char media;
  double result;
  printf("Insira o número de alunos\n");
  scanf("%d",&N);
  while (N>0) {
    printf("Insira as 3 notas do aluno e o tipo de média preferida (P para ponderada ou A para aritmética\n");
    scanf("%d %d %d %c",&nota1,&nota2,&nota3,&media);
    result=medias(nota1,nota2,nota3,media);
    N--;
    printf("%.2lf\n",result);
    }
  return 0;
}
*/