/*
#include <stdio.h>

int verificaSinal(int N){
  int sinaliza,positivo;
  if(N>=0){
    sinaliza=0;
  }else if(N<0){
    sinaliza=1;
    }
  return sinaliza;
  }

int main(){
  int N,valor,sinal;
  printf("Insira quantos valores você pretende inserir:\n");
  scanf("%d",&N);
  while(N>0){
  printf("Insira seu valor inteiro:\n");
  scanf("%d",&valor);
    N--;
    sinal=verificaSinal(valor);
    if(sinal==0){
       printf("Seu valor é Positivo!\n\n");
    }else if(sinal==1){
      printf("Seu valor é Negativo!\n\n");
    }
    }
  printf("Obrigado!");
  }
*/