/*
#include <stdio.h>

void crescente(int valor1,int valor2,int valor3){
  if (valor1<valor2){
    if (valor1<valor3){
      if (valor2<valor3){
        printf("A ordem crescente destes números é %d %d %d\n\n",valor1,valor2,valor3);
      }else if (valor2>valor3){
        printf("A ordem crescente destes números é %d %d %d\n\n",valor1,valor3,valor2);
      }
      }else if (valor1>valor3){
      printf("A ordem crescente destes números é %d %d %d\n\n",valor3,valor1,valor2);
      }
    }else if (valor1>valor2){
    if(valor1>valor3){
      if(valor3>valor2){
        printf("A ordem crescente destes números é %d %d %d\n\n",valor2,valor3,valor1);
      }else if (valor3<valor2){
        printf("A ordem crescente destes números é %d %d %d\n\n",valor3,valor2,valor1);
      }
    }else if (valor1<valor3){
      printf("A ordem crescente destes números é %d %d %d\n\n",valor2,valor1,valor3);
    }
    }
  }

int main(){
  int conjuntos=0,valor1=0,valor2=0,valor3=0;
  float result;
  printf("Insira o número de conjuntos:\n");
  scanf("%d",&conjuntos);
  while (conjuntos>0){
  printf("Insira 3 valores inteiros:\n");
  scanf("%d %d %d",&valor1,&valor2,&valor3);
    conjuntos--;
    crescente(valor1,valor2,valor3);
  }
}
*/