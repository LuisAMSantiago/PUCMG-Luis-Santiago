/*
#include <stdio.h>

void verifconceito(int mediafinal){
  if(mediafinal<=39){
    printf("Nota F\n\n");
    }else if(mediafinal>39 && mediafinal<=59){
    printf("Nota E\n\n");
    }else if(mediafinal>=60 && mediafinal<=69){
    printf("Nota D\n\n");
    }else if(mediafinal>=70 && mediafinal<=79){
    printf("Nota C\n\n");
    }else if(mediafinal>=80 && mediafinal<=89){
    printf("Nota B\n\n");
    }else if(mediafinal>=90){
    printf("Nota A\n\n");
    }
  }

int main(){
  int mediafinal=0,N=0,flag=0;
    printf("Insira o número de alunos:\n");
    scanf("%d",&N);
  while(N>0){
    N--;
    printf("Insira a média final do aluno(de 0 a 100):\n");
      scanf("%d",&mediafinal);
    verifconceito(mediafinal);
    }
  printf("Obrigado!\n");
  return 0;
}
*/