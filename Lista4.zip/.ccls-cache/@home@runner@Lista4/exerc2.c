/*
  #include <stdio.h>

float media(float salario,int numsalarios,int flag){
float mediaR,somasalarios=0;
  if (salario>0)
    numsalarios++;
  flag=numsalarios;
  printf("Insira um salário:\n");
  scanf("%f",&salario);
  somasalarios+=salario;
  if (flag==1){
    mediaR=somasalarios/numsalarios;
  }
  return mediaR;
  }

int main(){
  float salario,result;
  int flag=1,numsalarios=0;
  printf("Insira um salário:\n");
  scanf("%f",&salario);
  while(flag>0){
    result=media(salario,numsalarios,flag);
  }
  printf("%.2f",result);
}
*/