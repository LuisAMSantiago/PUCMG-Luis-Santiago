/*
#include <stdio.h>

double mediaaritmetica (char media,int nota1,int nota2,int nota3,int mediaA, int mediaP){
  if (media=='A') {
      mediaA=(nota1+nota2+nota3)/3;
    return mediaA;
    }
}

int main(void) {
  int nota1=0,nota2=0,nota3=0,N,mediaA,mediaP;
  char media;
  printf("Insira o número de alunos");
  scanf("%d",&N);
  if (N>0){
    printf("Agora, insira as 3 notas de 1 aluno e o tipo de média preferida (P para ponderada ou A para aritmética");
    scanf("%d %d %d %c",&nota1,&nota2,&nota3,&media);
  }else printf("O número de alunos é inválido!");
  return 0;
}
*/