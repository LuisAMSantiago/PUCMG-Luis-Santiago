/*
#include <stdio.h>
#include <string.h>
#define TAM 5

int somaA(int matriz[TAM][TAM]){
  int resultado=0, i=0, j=0;
  for (i=4, j=0; j<TAM; j++){
    resultado+=matriz[i][j];
  }
  return resultado;
}  
int somaB(int matriz[TAM][TAM]){
  int resultado=0, i=0, j=0;
  for (i=0, j=2; i<TAM; i++){
    resultado+=matriz[i][j];
  }
  return resultado;
}  
int somaC(int matriz[TAM][TAM]){
  int resultado=0, i=0, j=0;
  for (i=0, j=0; j<TAM; i++, j++){
    resultado+=matriz[i][j];
  }
  return resultado;
}  
int somaD(int matriz[TAM][TAM]){
  int resultado=0, i=0, j=0;
  for (i=4, j=0; j<TAM; i--, j++){
    resultado+=matriz[i][j];
  }
  return resultado;
}  
int somaE(int matriz[TAM][TAM]){
  int resultado=0, i=0, j=0;
  for (i=0; i<TAM; i++){
    for (j=0; j<TAM; j++){
      resultado+=matriz[i][j];
    }
  }
  return resultado;
}  

int main(void) {
  int matriz[TAM][TAM];
  int j=0, i=0, aux=0, result=0;
  char funcao='A';
  printf("Qual a soma desejada?\nA=Linha 4 da matriz\nB=Coluna 2 da matriz\nC=Diagonal Principal\nD=Diagonal secundária\nE=Todos elementos\n");
  scanf("%c", &funcao);
  printf("Digite os números:\n");
  for (i=0; i<5; i++){
    for (j=0; j<5; j++){
      scanf("%d", &aux);
      matriz[i][j]=aux;
    }
  }
  if (funcao=='A' || funcao=='a') result=somaA(matriz);
  if (funcao=='B' || funcao=='b') result=somaB(matriz);
  if (funcao=='C' || funcao=='c') result=somaC(matriz);
  if (funcao=='D' || funcao=='d') result=somaD(matriz);
  if (funcao=='E' || funcao=='e'){
    result=somaE(matriz);
  }
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("Sua matriz é");
  for (i=0; i<5; i++){
    printf("\n");
    for (j=0; j<5; j++){
      printf("%d\t", matriz[i][j]);
    }
  }
  printf("\n");
  printf("O resultado é %d\n", result);
  return 0;
}
*/