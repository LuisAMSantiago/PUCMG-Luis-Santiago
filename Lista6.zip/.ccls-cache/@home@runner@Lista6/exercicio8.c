/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LINHAS 4
#define COLUNAS 6

int somaMatriz(int matrizA[LINHAS][COLUNAS], int matrizB[LINHAS][COLUNAS], int i, int j){
  int matrizRES[LINHAS][COLUNAS], result=0;
      result=matrizA[i][j]+matrizB[i][j];
      matrizRES[i][j]=result;
 return matrizRES[i][j];
}
int diferencaMatriz(int matrizA[LINHAS][COLUNAS], int matrizB[LINHAS][COLUNAS], int i, int j){
  int matrizRES[LINHAS][COLUNAS], result=0;
      result=matrizA[i][j]-matrizB[i][j];
      matrizRES[i][j]=result;
 return matrizRES[i][j];
}
      
int main(void){
  int matrizA[LINHAS][COLUNAS], matrizB[LINHAS]    [COLUNAS], matrizS[LINHAS][COLUNAS], matrizD[LINHAS][COLUNAS];
  int j=0, i=0, aux=0, result=0;
  printf("Digite os números da matriz A:\n");
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
      scanf("%d", &aux);
      matrizA[i][j]=aux;
    }
  }
  printf("\n");
  printf("Digite os números da matriz B:\n");
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
      scanf("%d", &aux);
      matrizB[i][j]=aux;
    }
  }
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
      matrizS[i][j]=somaMatriz(matrizA, matrizB, i, j);
    }
  }
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
      matrizD[i][j]=diferencaMatriz(matrizA, matrizB, i, j);
    }
  }
  printf("\n");
  printf("A soma das suas matrizes são\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matrizS[i][j]);
    }
  }
  printf("\n");
  printf("A diferença das suas matrizes são\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matrizD[i][j]);
    }  
  }
  return 0;
}
*/