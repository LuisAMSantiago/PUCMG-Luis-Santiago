/*
#include <stdio.h>
#include <string.h>
#define TAM 4

int main(void) {
  int matriz[TAM][TAM];
  int j=0, i=0, aux=0, result=0;
  printf("Digite os números:\n");
  for (i=0; i<TAM; i++){
    for (j=0; j<TAM; j++){
      scanf("%d", &aux);
      matriz[i][j]=aux;
    }
  }
  printf("Sua matriz é");
  for (i=0; i<TAM; i++){
    printf("\n");
    for (j=0; j<TAM; j++){
      printf("%d\t", matriz[i][j]);
    }
  }
  printf("\n");
  printf("A diagonal principal é\n");
  for (i=0, j=0; j<TAM; i++, j++){
    printf("%d\t", matriz[i][j]);
  }
  printf("\n");
  printf("A soma dos elementos abaixo da diagonal principal é\n");
  for (i=1, j=0; j<3; i++, j++){
    result+=matriz[i][j];
  }
  for (i=2, j=0; j<2; i++, j++){
    result+=matriz[i][j];
  }
  result+=matriz[3][0];
  printf("%d", result);
  return 0;
}
*/