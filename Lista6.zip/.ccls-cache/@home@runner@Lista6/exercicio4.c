/*
#include <stdio.h>
#include <string.h>

int main(){
  char frase[256],FRASE[256];
  int pos;
printf("Insira uma frase (de até 256 caracteres):\n");
  gets(frase);
  for(pos=0;pos<256;pos++){
    if(frase[pos]=='\0'){
      break;
      }else if (pos==0 && (int)frase[pos]>=97 && (int)frase[pos]<=122){
      frase[pos]-=32;
      }else if((int)frase[pos]==32){
      pos++;
    if((int)frase[pos]>=97 && frase[pos]<=122){
      frase[pos]-=32;
      }
  }
  }
     printf("%s",frase);
    return 0;
  }
*/