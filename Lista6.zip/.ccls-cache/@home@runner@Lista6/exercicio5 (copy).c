#include<stdio.h>
#include<string.h>

int main(){
  char palavra[30];
  char inversa[30];
  int pos=0,pos2=0,tam_str=0;
  printf("Digite uma palavra\n");
  gets(palavra);
  for(pos=0;palavra[pos];pos++){
    if(palavra[pos]>=65 && palavra[pos]<=90){
      palavra[pos]+=32;
    }
    pos2=tam_str;
    tam_str++;
    }
  while(pos2>=0){
    strcpy(palavra,inversa);
    inversa[pos]=palavra[pos2];
    printf("%c",inversa[pos]);
    pos2--;
  }
  if(palavra==inversa){
    printf("Sua palavra é um palíndromo!")
  }else printf("Sua palavra não é um palíndromo!")
  }