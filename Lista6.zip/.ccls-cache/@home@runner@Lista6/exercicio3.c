/*
#include <stdio.h>
#include <string.h>

int contaVogais(char frase[]){
  int vogais=0,pos=0;
  for(pos=0;pos<256;pos++){
    if(frase[pos]=='\0'){
      break;
    }else if(frase[pos]=='a'){
      vogais++;
      }else if(frase[pos]=='e'){
      vogais++;
      }else if(frase[pos]=='i'){
      vogais++;
      }else if(frase[pos]=='o'){
      vogais++;
      }else if(frase[pos]=='u'){
      vogais++;
      }else if(frase[pos]=='A'){
      vogais++;
      }else if(frase[pos]=='E'){
      vogais++;
      }else if(frase[pos]=='I'){
      vogais++;
      }else if(frase[pos]=='O'){
      vogais++;
      }else if(frase[pos]=='U'){
      vogais++;
      }
    }
  return vogais;
}


int main(){
  char frase[256],vogais,pos,tam_vetor=0,subs;
printf("Insira uma frase (de até 256 caracteres):\n");
  gets(frase);
  vogais=contaVogais(frase);
  printf("Sua frase possui %d vogais!",vogais);
  return 0;
}
*/