/*
#include <stdio.h>
#define TAM_MAX 100

int main(void) {
  int linha1[TAM_MAX], linha2[TAM_MAX],
  tam_vetor1=0, tam_vetor2=0, maiorV=0, aux=0,
  i=0, j=0;
  for (i=0; i<TAM_MAX; i++){
    linha1[i]=0;
    linha2[i]=0;
  }
  printf("Digite os números da primeira linha
    (0 para parada):\n");
  for (i=0; i<TAM_MAX; i++){
    scanf("%d", &aux);
    if (aux==0){
      tam_vetor1=i++;
      break;
    }
    else {
      linha1[i]=aux;
    }
  }
  printf("Digite os números da segunda linha (0 para parada):\n");
  for (i=0; i<TAM_MAX; i++){
    scanf("%d", &aux);
    if (aux==0){
      tam_vetor2=i++;
      break;
    }
    else {
      linha2[i]=aux;
    }
  }
  if (tam_vetor1>tam_vetor2){
    maiorV=tam_vetor1;
    }
  else{
    maiorV=tam_vetor2;
  }
  printf("\n");
  printf("Sequência 1\n");
  for(i=0; i<maiorV; i++){
    printf("%d\t", linha1[i]);
  }
  printf("\n");
  printf("Sequência 2\n");
  for(i=0; i<maiorV; i++){
    printf("%d\t", linha2[i]);
  }
  printf("\n");
  printf("Soma\n");
  for (i=0; i<maiorV; i++){
    printf("%d\t", linha1[i]+linha2[i]);
  }
  printf("\n");
  printf("Soma invertida\n");
  j=maiorV;
  j--;
  for (i=0; i<maiorV; i++, j--){
    printf("%d\t", linha1[i]+linha2[j]);
  } 
  return 0;
}
*/