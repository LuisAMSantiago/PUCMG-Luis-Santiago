/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LINHAS 10
#define COLUNAS 10

void trocaLinha(int matrizA[LINHAS][COLUNAS]){
  int matrizRES[LINHAS][COLUNAS], result=0, i=0, j=0;
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
        matrizRES[i][j]=matrizA[i][j];
    }
  }
  for (j=0; j<COLUNAS; j++){
    matrizRES[1][j]=matrizA[7][j];
    matrizRES[7][j]=matrizA[1][j];
  }
  printf("Sua matriz modificada é:\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matrizRES[i][j]);
    }
  }
}
void trocaColuna(int matrizA[LINHAS][COLUNAS]){
  int matrizRES[LINHAS][COLUNAS], result=0, i=0, j=0;
    for (i=0; i<LINHAS; i++){
      for (j=0; j<COLUNAS; j++){
        matrizRES[i][j]=matrizA[i][j];
      }
    }
    for (i=0; i<LINHAS; i++){
      matrizRES[i][3]=matrizA[i][9];
      matrizRES[i][9]=matrizA[i][3];
    }
  printf("Sua matriz modificada é:\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matrizRES[i][j]);
    }
  }
}
void trocaDiagonal(int matrizA[LINHAS][COLUNAS]){
  int matrizRES[LINHAS][COLUNAS], result=0, i=0, j=0, k=0, l=0;
    for (i=0; i<LINHAS; i++){
      for (j=0; j<COLUNAS; j++){
        matrizRES[i][j]=matrizA[i][j];
      }
    }
    for (i=0, j=0, k=0, l=9; j<LINHAS; i++, j++, k++, l--){
      matrizRES[i][j]=matrizA[k][l];
      matrizRES[k][l]=matrizA[i][j];
    }
  printf("Sua matriz modificada é:\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matrizRES[i][j]);
    }
  }
}
      
int main(void){
  int matriz[LINHAS][COLUNAS];
  int j=0, i=0, aux=0, result=0;
  char funcao='A';
  printf("Qual a troca a ser realizada?\nA-Linha 2 com a linha 8\nB-Coluna 4 com a coluna 10\nC-Diagonal principal com a diagonal secundária\n");
  scanf("%c", &funcao);
  printf("Digite os números da matriz:\n");
  for (i=0; i<LINHAS; i++){
    for (j=0; j<COLUNAS; j++){
      scanf("%d", &aux);
      matriz[i][j]=aux;
    }
  }
  printf("Sua matriz é:\n");
  for (i=0; i<LINHAS; i++){
    printf("\n");
    for (j=0; j<COLUNAS; j++){
      printf("%d\t", matriz[i][j]);
    }
  }
  printf("\n");
  if (funcao=='A' || funcao=='a') trocaLinha(matriz);
  else if (funcao=='B' || funcao=='b') trocaColuna(matriz);
  else if (funcao=='C' || funcao=='c') trocaDiagonal(matriz);
  return 0;
}
*/