#include <stdio.h>
#include <string.h>

int palindromopar (char frase[], int i, int j, int resultado){
  if ((int) frase[i]== (int)frase[j]) resultado++;
  printf("%d", resultado);
  if (i<j) return resultado;
  else return palindromopar(frase, i--, j++, resultado);
}
int palindromoimpar (char frase[], int i, int j, int resultado){
  if ((int) frase[i]==(int)frase[j]) resultado++;
  printf("%d", resultado);
  if (i==j) return resultado++;
  else return palindromoimpar(frase, i--, j++, resultado);
}
int main(void) {
  char palavra[100];
  int cont=0, i=0, result=0, ai=0;
  printf("Digite a palavra:\n");
  gets(palavra);
  for (i=0; palavra[i]!='\0'; i++);
  if (i%2!=0){
    ai=palindromoimpar(palavra, i, cont, result);
    printf("%d", ai);
  }
  else if (i%2==0){
    ai=palindromopar(palavra, i, cont, result);
    printf("%d", ai);
  }
  return 0;
}