/*
#include <stdio.h>
#define TAM_MAX 50

int main(){
  int vetor[TAM_MAX],pos,tam_vetor=0,subs;
  printf("Insira até 50 inteiros(insira -99 para encerrar):\n");
  for(pos=0;pos<TAM_MAX;pos++){
    scanf("%d",&subs);
    tam_vetor=pos;
    if(subs==-99){
      break;
    }else vetor[pos]=subs;
    }
  printf("Valores\tÍndices\n");
  for(pos=0;pos<tam_vetor;pos++){
    if(vetor[pos]%2==0){
    printf("%d\t\t%d\n",vetor[pos],pos);
  }
    }
  return 0;
}
*/