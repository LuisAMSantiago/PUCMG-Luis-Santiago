#include <stdio.h>

int serie (int n1, int n2){
  if(n1==n2){return n2;
    }else printf("%d ", n1); return serie (n1+1, n2);
}

int main(void){
  int num1=0, num2=0, result=0;
  printf("Digite o 1° número\n");
  scanf("%d", &num1);
  printf("Digite o 2° número\n");
  scanf("%d", &num2);
  if(num1<num2){
  result=serie(num1, num2);
  printf("%d", result);
  }else printf("Número inválido!");
  return 0;
}