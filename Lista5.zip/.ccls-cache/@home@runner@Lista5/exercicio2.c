#include <stdio.h>

int calcDigit(int num){
  int somadigit=0,digito=0;
    if(num>=-9 && num<=9){
      somadigit=num;
      }else if(num>=10){
      digito=num%10;
    num=num/10;
    somadigit=digito+calcDigit(num);
      }
  return somadigit;
  }

int main() {
  int num=0;
  printf("Insira um número inteiro:\n");
  scanf("%d",&num);
  printf("A soma dos dígitos do número é %d",calcDigit(num));
  return 0;
}