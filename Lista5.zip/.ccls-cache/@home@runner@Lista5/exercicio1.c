#include <stdio.h>

int calcDigit(int num){
  int numdigit=1;
    if(num>=-9 && num<=9){
      numdigit=1;
      }else if(num>=10){
    num=num/10;
    numdigit+=calcDigit(num);
      }
  return numdigit;
  }

int main() {
  int num=0;
  printf("Insira um número inteiro:\n");
  scanf("%d",&num);
  printf("O número inserido possui %d dígitos",calcDigit(num));
  return 0;
}