#include <stdio.h>

int calcDigit(int num){
  int numdigit=0;
    if(num>=-9 && num<=9){
      numdigit=1;
      }else if((num/10)>=1){
      numdigit++;
      calcDigit(num);
      }
  numdigit++;
  return numdigit;
}

int main() {
  int num=0;
  printf("Insira um número inteiro:\n");
  scanf("%d",&num);
  printf("O número inserido possui %d dígitos",calcDigit(num));
  return 0;
}