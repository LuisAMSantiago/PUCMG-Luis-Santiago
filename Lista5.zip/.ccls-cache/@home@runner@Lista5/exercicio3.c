#include <stdio.h>

int calcDiv(int numerador,int denominador){
  int divisao=0;
  if(numerador==0){
    divisao+=0;
  }else if(numerador>0){
    divisao++;
    numerador-=denominador;
    divisao=1+calcDiv(numerador,denominador);
  }
  return divisao;
}

int main(){
  int numerador=0,denominador=0;
  printf("Insira o numerador e o denominador:\n");
  scanf("%d %d",&numerador,&denominador);
  printf("O resultado da sua divisão é: %d",calcDiv(numerador,denominador));
}