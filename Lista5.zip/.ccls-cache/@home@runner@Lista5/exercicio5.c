#include <stdio.h>
double fatorial(double num){
  if(num<=0){
    return 1;
  }else return fatorial(num-1)*num;
}

double serie(double num){
  if (num<=0){
    return 0;
    }else return serie (num-1)+ 1/fatorial (num);
}

int main(void){
  double num=0, result=0;
  printf("Insira o número para o cálculo:\n");
  scanf("%lf", &num);
  result=serie(num);
  printf("%lf", result);
  return 0;
}