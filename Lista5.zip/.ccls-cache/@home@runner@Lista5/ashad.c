#include <stdio.h>

int divisao(int numerador, int denominador){
  if (numerador<=denominador) return numerador;
  else return divisao (numerador-denominador, denominador);
}
int main(void){
  int num=0, den=0, result=0;
  printf("Digite o numerador\n");
  scanf("%d", &num);
  printf("Digite o denominador\n");
  scanf("%d", &den);
  result=divisao(num, den);
  printf("%d", result);
    return 0;
}