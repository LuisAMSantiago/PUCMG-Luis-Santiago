/*
#include <stdio.h>

int main() {
  int a=0,b=0,aux=0;
  int *pa,*pb;
  printf("Insira seus dois valores\n");
  scanf("%d %d",&a,&b);
  pa=&a;
  pb=&b;
  while(aux>=0){
    if(pa<pb){
      printf("o segundo endereço é maior");
    }else if(pa>pb){
      printf("o primeiro endereço é maior");
    }//esses prints aqui eu coloquei sem nenhum motivo específico, só pra mostrar o código funcionando e printas o resultado mesmo
    aux--;
  }
  return 0;
}//meu código inicialmente decidiu alocar a primeira variável em uma posição maior que a segunda variável, então o resultado é sempre a primeira posição.
*/