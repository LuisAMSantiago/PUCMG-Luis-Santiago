/*
void func(int *px, int *py){
  px = py;
  *py = (*py) * (*px);
  *px = *px + 2;
}

int main (){
  int x, y;
  scanf("%d", &x);
  scanf("%d", &y);
  func(&x,&y);
  printf("x = %d, y = %d", x, y);
  return 0;
}
*/

/*
x    y    px    py
5    6    
5    6    &x    &y
5    6    &y    &y
5    36   &y    &y
5    38   &y    &y
5    38
*/