/*
#include <stdio.h>
int main()
{
int x, *p, **q;
p = &x;
q = &p;
x = 10;
printf("\n%d\n", &q);
  //Esse printf imprime o espaço de memória do ponteiro, e não o ponteiro em si
return(0);
}

//Código correto:
#include <stdio.h>
int main()
{
int x, *p, **q;
p = &x;
q = &p;
x = 10;
printf("\n%d\n", **q);
return(0);
}
*/