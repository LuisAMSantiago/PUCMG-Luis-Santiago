/*
#include <stdio.h>

int organiza(int **d,int **e,int **f){
  int aux=0;
  if(**d==**e && **e==**f){
    return 1;
  }else{
    if(**d==**e){
      if(**d>**f){
        aux=**d;
        **d=**f;
        **e=aux;
        **f=aux;
      }else{
        **d=**d;
        **e=**e;
        **f=**f;
      }
    }else{
      if(**d<**e){
      if(**d<**f){
        if(**e<=**f){
        **d=**d;
        **e=**e;
        **f=**f;
        }else if(**e>**f){
        **d=**d;
        aux=**e;
        **e=**f;
        **f=aux;
        }
      }else if(d>f){
        aux=**d;
        **d=**f;
        **f=**e;
        **e=aux;
      }
    }else if(d>e){
      if(d<f){
        aux=**d;
        **d=**e;
        **e=aux;
        **f=**f;
      }else if(e>f){
        aux=**d;
        **d=**f;
        **e=**e;
        **f=aux;
      }else if(d>f){
        aux=**d;
        **d=**f;
        **f=**e;
        **e=aux;
      }
    }
    }
    return 0;
  }
}
//Foi fácil, porém longo escrever td kkk
int main(){
  int a=0,b=0,c=0;
  int *pa,*pb,*pc;

  pa=&a;
  pb=&b;
  pc=&c;
  
  printf("Insira três valores inteiros:\n");
  scanf("%d %d %d",&a,&b,&c);
  organiza(&pa,&pb,&pc);
  printf("%d %d %d",a,b,c);
}
*/