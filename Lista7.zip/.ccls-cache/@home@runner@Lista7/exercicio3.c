/*#include <stdio.h>

int main() {
  int valor=0;
  int *valorPtr;
  printf("Insira um valor\n");
  scanf("%d",&valor);
  valorPtr=&valor; //Opção C é verdadeira, pois o ponteiro valorPtr aponta para o endereço da variável valor;
  if(valor==&valorPtr){
    printf("Opção A - Verdadeira.\n");
    //A opção A é falsa pois o valor da varíavel valor é igual ao valor inserido pelo usuário, e não ao endereço do ponteiro.
  }else{
    printf("Opção A - Falsa.\n");
  }
  if(valor==*valorPtr){
    printf("Opção B - Verdadeira.\n");
    //A opção B é verdadeira pois o * simboliza o desreferenciamento de um ponteiro, ou seja, enquanto valorPtr representa o conteúdo de valorPtr(que é igual ao espaço de memória da variável valor), *valorPtr representa o conteúdo do espaço = valorPtr (se valorPtr=120, então *valorPtr busca o conteúdo do espaço 120).
  }else{
    printf("Opção B - Falsa.\n");
  }
  if(valorPtr==&valor){
    printf("Opção C - Verdadeira.\n");
  }else{
    printf("Opção C - Falsa.\n");
  }
  */
  //if(valorPtr==*valor){ Aqui a comparação valorPtr==*valor não funciona, pois "valor" é uma variável, e não um ponteiro, portanto a opção D é sempre falsa.
    //printf("Opção D - Verdadeira.\n");
  //}
  /*printf("Opção D - Falsa.\n");
  
  return 0;
}
*/