/*
#include <stdio.h>

int main(){
  int i=10;
  int *pi;
  char c='J';
  char *pc;
  float f=9.99;
  float *pf;

  pi=&i;
  pc=&c;
  pf=&f;
  
  printf("Endereço\tConteúdo\n");
  printf("%d\t%d\n",pi,i);
  printf("%d\t%c\n",pc,c);
  printf("%d\t%f\n",pf,f);
  printf("Agora, insira novos valores, nessa ordem: (inteiro char float)\n");
  scanf("%d %c %f",&i,&c,&f);
  printf("Endereço\tConteúdo\n");
  printf("%d\t%d\n",pi,i);
  printf("%d\t%c\n",pc,c);
  printf("%d\t%f\n",pf,f);
  return 0;
}
*/