#include <stdio.h>

int main(){
  float piranha=9.99,piranha2;
  scanf("%f",&piranha2);
}