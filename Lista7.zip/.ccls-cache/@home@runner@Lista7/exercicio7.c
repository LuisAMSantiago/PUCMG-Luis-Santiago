/*
#include <stdio.h>

int testaMaior(int *e, int *f){
  int maior=0, menor=0;
  if(*e>*f){
    menor=*f;
    maior=*e;
    *e=maior;
  }
  else{
    menor=*e;
    maior=*f;
    *e=maior;
  }
  return menor;
}

int main(){
  int a=0, b=0;
  int *c=&a, *d=&b;
  printf("Insira dois valores(diferentes):\n");
  scanf("%d %d", c, d);
  b=testaMaior(c, d);
  printf("Maior: %d\tMenor: %d", a, b);
  return 0;
}
*/