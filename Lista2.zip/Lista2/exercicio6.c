#include <stdio.h>
#include <math.h>

int main() {
  float salario;
  char aumento;
  int a,b,c;
  printf("Insira o salário do empregado e uma das opções de aumento (a, b ou c):\n");
  scanf("%f %c",&salario,&aumento);
  switch (aumento) {
    case 'a': salario=(salario*8)/100;
    break;
    case 'b': salario=(salario*11)/100;
    break;
    case 'c': if (salario<=1000){
      salario+=350;
    }else if (salario>1000){
      salario+=200;
    }
    break;
    default: printf("Opção inválida!");
    break;
  };
  printf("O novo salário é de R$%.2f",salario);
  return 0;
}