#include <stdio.h>
#include <math.h>

int main() {
  float diaria,diariap,valor1,valor2,diferenca;
  printf("Insira o valor da diária:\n");
  scanf("%f",&diaria);
  diariap=diaria-(25*diaria)/100;
  valor1=((80*75)/100)*diariap;
  //valor1 é o valor total arrecadado com 80% de ocupação e diária promocional;
  valor2=((50.f*75.f)/100.f)*diaria;
    //valor2 é o valor total arrecadado com 50% de ocupação e diária normal;
  diferenca=valor1-valor2;
  printf("A diária promocional equivale à R$%.2f.\nO valor total arrecadado com 80 por cento de ocupação e diária promocional equivale à R$%.2f\nO valor total arrecadado com 50 por cento de ocupação e diária normal equivale à R$%.2f\nE a diferença entre esses valores arrecadados é de R$%.2f.",diariap,valor1,valor2,diferenca);
  return 0;
  }