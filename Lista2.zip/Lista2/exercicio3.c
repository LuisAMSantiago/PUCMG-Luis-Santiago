#include <stdio.h>
#include <math.h>

int main() {
  int a;
  float b;
  printf("Insira um ano abaixo (Ex: 2016, 1990, ect):\n");
  scanf("%d",&a);
    if (a%100!=0 && a%4==0) {
      printf("Bissexto.");
    }else if (a%400==0) {
      printf("Bissexto.");
    }else {
      printf("Não é bissexto.");
    }
  return 0;
  }