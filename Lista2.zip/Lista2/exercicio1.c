#include <stdio.h>
#include <math.h>

int main() {
  int a,u,d,c,m;
  printf("Insira um número positivo inteiro de 4 algarismos:\n");
  scanf("%d",&a);
  if(a>999 && a<10000){
    u=a%10;
    d=(a%100)/10;
    c=(a%1000)/100;
    m=(a%10000)/1000;
    printf("%d%d%d%d",u,d,c,m);
    }
  return 0;
}