#include <stdio.h>
#include <math.h>

int main() {
  float nota;
  printf("Insira a nota do aluno (de 0 a 10):\n");
  scanf("%f",&nota);
  if (nota>=0 && nota<=10){
    if (nota<5) {
      printf("Insatisfatório.");
    }else if (nota>=5 && nota<7) {
      printf("Regular.");
    }else if (nota>=7 && nota<8) {
      printf("Bom.");
    }else if (nota>=8 && nota<=10) {
      printf("Ótimo");
    }
  }else if (nota<0 || nota>10) {
    printf("Insira uma nota de 0 a 10!!");
  }
  return 0;
  }