#include <stdio.h>
#include <math.h>

int main() {
  int s;
  float a,p,pi;
  printf("Insira respectivamente a altura(ex:1.58 o peso(ex 51.90 e o sexo da pessoa(0 para feminino ou 1 para masculino):\n");
  scanf("%f %f %d",&a,&p,&s);
  if (s!=0 && s!=1) {
    printf("Reinicie o programa.");
    return 0;
  }else if (s==1) {
    pi=(72.7*a)-58;
  }else if (s==0) {
    pi=(62.1*a)-44.7;
  }
  if (pi==p) {
    printf("Seu peso ideal seria de %.2fkg, portanto você está no peso ideal!",pi);
  }else if (p>pi) {
    printf("Seu peso ideal seria de %.2fkg, portanto você está acima do peso ideal.",pi);
  }else if (p<pi) {
    printf("Seu peso ideal seria de %.2fkg, portanto você está abaixo do peso ideal.",pi);
  }
  return 0;
  }