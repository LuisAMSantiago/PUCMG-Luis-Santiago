#include <stdio.h>
#include <math.h>
int main()
{
  int a,b,c,d,e,f;
  b=60;
  printf("Insira um valor em segundos, para que ele seja convertido em horas, minutos e segundos:");
scanf("%d",&a);
  c= a/3600;
  d= a%3600;
  e= d/60;
  f= d%60;
  
  printf("%d segundos equivalem à %d horas, %d minutos e %d segundos!",a,c,e,f);
}