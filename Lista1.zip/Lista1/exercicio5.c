#include <stdio.h>
#include <math.h>
int main()
{
  long int a,b,c,d;
  a= -1*pow(2,31);
  b= -1*a;
  c= a;
  d= b-1;
  printf("Os limites que um inteiro comporta são:\n%ld valores (limite máximo) \ne \n%ld valores (limite mínimo).\n\nOs limites, sem contar o valor que seria suposto ao -0, são:\n%ld valores (máximo) \ne \n%ld valores (mínimo)",b,a,d,c);
}