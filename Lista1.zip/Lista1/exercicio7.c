#include <stdio.h>
#include <math.h>
int main()
{
  int a,b,c,d,pra,prb,prc;
  float e,pad,pbd,pcd;
  printf("Insira quanto cada apostador apostou (máximo 3 apostadores) e o valor do prêmio:");
  scanf("%d %d %d %d",&a,&b,&c,&d);
  e= (a+b+c);
  pad= (a/e);
  pbd= (b/e);
  pcd= (c/e);
  pra= pad*d;
  prb= pbd*d;
  prc= pcd*d;
  printf("O apostador 1 ganharia R$%d do prêmio.\nO apostador 2 ganharia R$%d do prêmio.\nO apostador 3 ganharia R$%d do prêmio.\n",pra,prb,prc);
}