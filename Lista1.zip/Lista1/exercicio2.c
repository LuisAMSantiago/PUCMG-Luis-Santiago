#include <stdio.h>
int main()
{
  float primeiro, C;
  primeiro = 500.0;
  C = primeiro*((1+0.01)*(1.01*1.01));

  printf("No quarto mes eu tenho %.2f reais na poupança\n", C);
  return 0;
}