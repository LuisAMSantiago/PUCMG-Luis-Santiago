int main()
{
  int a,b,c,d,e,f,g,h,i,j,k,l;
  a= 2;
  b= 4;
  c= pow(2,4);
  printf("Um binário de 4 bits é capaz de comportar até %d diferentes combinações de 1 e 0.\n\n", c);

  printf("Agora, insira 4 valores referentes aos bits de um binário (zeros e ums) para que seja convertido o seu valor decimal (com espaçamentos entre cada valor):");
  scanf("%d %d %d %d",&d,&e,&f,&g);
  h= d*(pow(2,4-1));
  i= e*(pow(2,4-2));
  j= f*(pow(2,4-3));
  k= g*(pow(2,4-4));
  l= h+i+j+k;
  printf("O valor decimal do binário %d %d %d %d = %d",d,e,f,g,l);
}