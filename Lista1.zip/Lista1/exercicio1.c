#include <stdio.h>
#include <math.h>

int main(void){
  int x;
  float y,z;
  printf("Insira um ângulo em graus para cálculo do seno:");
  scanf("%d",&x);
  y=3.14;
  z=x*y/180;
  printf("Seno = %f", sin(z));
}