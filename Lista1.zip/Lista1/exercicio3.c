#include <stdio.h>
#include <math.h>
int main()
{
  int a, b, c, s, r;
  printf("Indique os 3 valores do triângulo, cateto a, cateto b, e hipotenusa, respectivamente:");
  scanf("%d %d %d", &a, &b, &c);
  s = (a+b+c)/2;
  r = sqrt(s*(s-a)*(s-b)*(s-c));
  printf("A área do triângulo equivale à: %d", r);
}