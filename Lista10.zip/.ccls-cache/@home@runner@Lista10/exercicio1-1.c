#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
char nome[50];
int nota;
}notas;

int main() {
  notas *nt;
  int i, j, *matricula, *matricula2, linhas, *nota, *media;
  char leitura[50],leitura2[50], text[300], quebra = '\n';
  FILE *al = fopen("alunos.txt", "r");
  FILE *no = fopen("notas.txt","r");
  fread(text, sizeof(char), 300, al);
  for (i = 0; i < strlen(text); i++) {
    if (text[i] == quebra) {
      linhas++;
    }
  }
  fseek (al, 0, SEEK_SET);
  nt = (notas*)malloc(linhas * sizeof(notas));
  matricula = (int *)calloc((linhas + 1), sizeof(int));
  matricula2 = (int *)calloc((linhas + 1), sizeof(int));
  nota = (int *)malloc((linhas + 1) * sizeof(int));
  media = (int *)calloc((linhas + 1), sizeof(int));
  strcpy(leitura,(char*)calloc((linhas+1),sizeof(char)));
  i = 0;
  while (!feof(al)) {
    fscanf(al, "%s", leitura);
    //printf("1\t%s\n", leitura);
    strcat(leitura, " ");
    //printf("2\t%s\n", leitura);
    fscanf(al, "%s", leitura2);
    //printf("3\t%s\n", leitura2);
    strcat(leitura, leitura2);
    //printf("4\t%s\n", leitura);
    fscanf(al, "%d\n", &matricula[i]);
    //printf("5\t%d\n\n", matricula[i]);
    strcpy(nt[i].nome,leitura);
    //nt[i].nome=leitura;
    //printf("\nAQUI %s",nt[i].nome);
    i++;
  }
  fclose(al);
    i=0;
    j=0;
  while (!feof(no)) {
    fscanf(no, "%d\n", &matricula2[i]);
    //printf("\t%d", matricula2[i]);
    for(i=0;i<=linhas;i++){
      fscanf(no,"%d",&nota[i]);
      printf("\n\t%d",nota[i]);
    }
    fscanf(no,"%d",&nota[i]);
    fscanf(no,"%d",&nota[i]);
    fscanf(no,"%d",&nota[i]);
    fscanf(no,"%d",&nota[i]);
    printf("\tAAAAAAAAA%d",nota[i]);
    /*printf("\t%d",nota[i][j+1]);
    printf("\t%d",nota[i][j+2]);
    printf("\t%d",nota[i][j+3]);*/
    //i++;
    j++;
  }
  printf("\n\n");
  for(i=0;i<linhas+1;i++){
    for(j=0;j<=linhas+1;j++){
      //printf("ABC\t%d\n",matricula[i]);
      printf("%d\n",matricula2[j]);
      if(matricula[i] == matricula2[j]){
        j=0;
        media[i] = (nota[j]+nota[j+1]+nota[j+2]+nota[j+3])/4;
        for(i=0;i<linhas+1;i++){
          for(j=0;j<linhas+1;j++){
            printf("\nNota1: %d",nt[i].nota);
            /*printf("\nNota2: %d",nt[i].nota[j]);
            printf("\nNota3: %d",nt[i].nota[j]);
            printf("\nNota4: %d",nt[i].nota[j]);
            printf("\nMedia: %d\n",media[i]);*/
          }
        }
        break;
      }
    }
  }
  for(i=0;i<=linhas;i++){
    printf("\nAQUI %s",nt[i].nome);
    printf("\tNota: %d",nt[i].nota);
  }
  /*for(i=0;i<linhas+1;i++){
    printf("\t%s",nt[i].nome);
  }*/
  // seekset
  // seekcur
}