/*#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ERRO -1

/*
int lista_por_inicial(char **lista,char letra,int n){
  for(i=0;i<n;i++){
    if(lista[i]==p){
      printf("%s",lista[i])
    }
  }
}


int encontra_nome(char **lista,char nome[],int n){
  int result,i,toget=0;
  for(i=0;i<n;i++){
    result=strcmp("togepi",nome);
    if(result==0){
      printf("você possui um Togepi na %d posição!",i+1);
      toget++;
      return i;
    }else{
      printf("Você não possui um Togepi!");
      return ERRO;
    }
    if(toget>1){
      printf("Você possui %d Togepis",toget);
    }
  }
  return 0;
}
  
int main(){
  char **meus_pokemons, poke[31],togepi[7]="togepi";
  int n,i;

  printf("Quantos pokemóns você possui?\n");
  scanf("%d",&n);
  meus_pokemons=(char **)malloc(n*sizeof(char));
  for(i=0;i<n;i++){
      printf("Insira o nome do %d° pokémon:\n",i+1);
      scanf("%s",poke);
      meus_pokemons[n]=malloc(strlen(poke)*sizeof(char));
  }
  encontra_nome(meus_pokemons,togepi,n);
  //lista_por_inicial(**lista,letra,n);
  
  return 0;
}
*/