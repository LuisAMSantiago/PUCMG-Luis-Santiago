#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ERRO -1

/*
int lista_por_inicial(char **lista,char letra,int n){
  for(i=0;i<n;i++){
    if(lista[i]==p){
      printf("%s",lista[i])
    }
  }
}
*/

int encontra_nome(char **lista,char *nome,int n){
  int result;
  for(i=0;i<n;i++){
    result=strcmp("togepi",lista);
    if(result=0){
      printf("Você possui um Togepi!");
    }else{
      printf("Você não possui um Togepi!");
    }
  }
}

int main(){
  char **meus_pokemons, poke[31],togepi[7]="togepi";
  int n,i;

  printf("Quantos pokemóns você possui?\n");
  scanf("%d",&n);
  meus_pokemons=(char **)malloc(n*sizeof(char));
  for(i=0;i<n;i++){
    for(i=0;i<n;i++){
      printf("Insira o nome do %d° pokémon:\n",i+1);
      scanf("%s",poke);
      meus_pokemons[n]=malloc(strlen(poke)*sizeof(char));
    }
  }
  encontra_nome(meus_pokemons,togepi,n);
  //lista_por_inicial(**lista,letra,n);
  
  return 0;
}