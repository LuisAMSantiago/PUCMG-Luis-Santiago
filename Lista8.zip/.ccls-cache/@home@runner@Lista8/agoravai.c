#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ERRO -1

int num_pokemons_com_p(char **lista, char letra,int num_poke){
  int i=0,num_poke_p=0;
  for(i=0;i<num_poke;i++){
    if(lista[i][0]==letra){
      num_poke_p++;
    }
  }
  return num_poke_p;
}

char** lista_por_inicial(char **lista, char letra,int num_poke){
  int i=0,comp=0,num_poke_p=0;;
  char **lista_com_letra,*pokemon;
  for(i=0;i<num_poke;i++){
    if(lista[i][0]==letra){
      num_poke_p++;
    }
  }
  lista_com_letra=(char**)malloc(num_poke_p*sizeof(char*));
  for(i=0;i<num_poke_p;i++){
    if(lista[i][0]==letra){
      pokemon=lista[i];
      lista_com_letra[num_poke_p]=(char*)calloc(strlen(pokemon),sizeof(char));
    }
  }
  return lista_com_letra;
}

int encontra_nome(char **lista,char *nome,int num_poke){
  int i=0,comp=0;
  for(i=0;i<num_poke;i++){
    comp=strcmp(lista[i],nome);
    if(comp==0){
      printf("\nVocê possui um togepi na %d° posição\n\n",(i+1));
      return i;
    }
  }
  return ERRO;
}

int main(){
  int num_poke=0,i,pokeP;
  char **meus_pokemons,pokemon[31],**p;

  printf("Caso você possua dois pokémons iguais (Ex: 2 Kadabras), não é necessário inserir todos eles, insira apenas um.\n\n");
  printf("Insira o número de pokémons que você possui:\n");
  scanf("%d",&num_poke);
  if(num_poke<1){
    printf("Parece que você ainda não possui nenhum pokémon! :(");
  }
  meus_pokemons=(char**)malloc(num_poke*sizeof(char*));
  for(i=0;i<num_poke;i++){
    printf("Insira o %d° pokémon (apenas letras minúsculas):\n",(i+1));
    scanf("%s",pokemon);
    meus_pokemons[i]=(char*)calloc(strlen(pokemon),sizeof(char));
    strcpy(meus_pokemons[i],pokemon);
  }
  encontra_nome(meus_pokemons,"togepi",num_poke);
  lista_por_inicial(meus_pokemons,'p',num_poke);
  pokeP=num_pokemons_com_p(meus_pokemons,'p',num_poke);
  p=lista_por_inicial(meus_pokemons,'p',num_poke);
  for (i=0;i<pokeP;i++){
    printf("Pokémons com a letra inicial P:\n\n%s",*(p+i));
  }
  return 0;
}