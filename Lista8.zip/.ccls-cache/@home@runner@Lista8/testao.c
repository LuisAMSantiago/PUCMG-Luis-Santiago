/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ERRO -1



void encontra_nome(char **lista,char nome[],int n){
int result,i;
for(i=0;i<n;i++){
result=strcmp("togepi", lista[i]);
if(result==0){
printf("\nVocê possui um Togepi!");
}else{
printf("\nVocê não possui um Togepi!");
}
}
}



int main(){
char poke[31],togepi[7]="togepi";
int n,i;

printf("Quantos pokemóns você possui?\n");
scanf("%d",&n);



char *meus_pokemons[n];
for(i=0;i<n;i++){
for(i=0;i<n;i++){
printf("Insira o nome do %d° pokémon:\n",i+1);
scanf("%s",poke);
meus_pokemons[i]=(char*)malloc(strlen(poke)*sizeof(char));
strcpy(meus_pokemons[i], poke);
}
}
encontra_nome(meus_pokemons,togepi,n);



return 0;
}
*/