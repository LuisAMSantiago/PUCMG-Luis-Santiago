/*
#include <stdio.h>
#include <stdlib.h>
#define FALSE 0
#define TRUE 1
void inverte(int *v,int n){
  int i, j=0;
  n-=1;
  for(i=0;i<=n/2;i++){
    j=*(v+i);
    *(v+i)=*(v+n-i);
    *(v+n-i)=j; 
  }
}
void preenche(int *v,int n,int valor,int is_aleatorio){
  int i;
  if(is_aleatorio==TRUE){
    for (i=0;i<n;i++){
      *(v+i)=rand()%101;
    }
  }else if(is_aleatorio==FALSE){
    for(i=0;i<n;i++){
      *(v+i)=valor;
    }
  }
}

void imprime(int *v,int n){
  int i;
for(i=0;i<n;i++)
  printf("%d\t",*(v+i));
  printf("\n");
}

int *aloca(int n,int preenche){
  if(preenche==TRUE){
    return (int*)calloc(n,sizeof(int));
  }else if(preenche==FALSE){
    return (int*)malloc(n*sizeof(int));
  }
}

int main(){
  int n;
  int *v1,*v2;
  printf("Insira o valor de n:\n");
  scanf("%d",&n);
  v1=aloca(n,FALSE);
  v2=aloca(n,TRUE);
  imprime(v1,n);
  imprime(v2,n);
  printf("\n");
  preenche(v1,n,0,TRUE);
  imprime(v1,n);
  printf("\n");
  inverte(v1,n);
  inverte(v2,n);
  imprime(v1,n);
  imprime(v2,n);
}
*/