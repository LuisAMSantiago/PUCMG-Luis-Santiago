#include <stdio.h>
#include <stdlib.h>

int main() {
  int N = 0, *T, i, P, M, numP = 0, numM = 0;
  scanf("%d", &N);
  if (N >= 1 && N <= 1000) {
    T = (int *)calloc(N, sizeof(int));
    for (i = 0; i < N; i++) {
      scanf("%d", &T[i]);
    }
    for (i = 0; i < N; i++) {
      if (T[i] != 1 && T[i] != 2) {
        return 0;
      }
    }
    scanf("%d", &P);
    if (P >= 0 && P <= 1000) {
      scanf("%d", &M);
      if (M >= 0 && M <= 1000) {
        if (N <= (P + M)) {
          for (i = 0; i < N; i++) {
            if (T[i] == 1) {
              numP++;
            } else if (T[i] == 2) {
              numM++;
            }
          }
          if (numP == P && numM == M) {
            printf("S");
          } else {
            printf("N");
          }
        }
      }
    }
  }
  return 0;
}