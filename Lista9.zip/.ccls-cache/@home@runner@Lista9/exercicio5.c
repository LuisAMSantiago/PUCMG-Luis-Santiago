#include <stdio.h>
#include <string.h>

enum notas{w=1,h,q,e,s,t,x};

typedef struct{
char letra[2];
float duracao;
}nota;

int main(){
  nota nota2[7];
  int soma_dos_certos=0,aux=0,i=0;
  char compasso[64];

  while(1){
    float soma_do_compasso=0;
    printf("Insira um compasso(apenas letras maiúsculas) (insira 0 para encerrar):\n");
    scanf("%s",compasso);
    strcpy(nota2[0].letra,"W");
      nota2[0].duracao=1;
    strcpy(nota2[0].letra,"H");
      nota2[0].duracao=1/2;
    strcpy(nota2[0].letra,"Q");
      nota2[0].duracao=1/4;
    strcpy(nota2[0].letra,"E");
      nota2[0].duracao=1/8;
    strcpy(nota2[0].letra,"S");
      nota2[0].duracao=1/16;
    strcpy(nota2[0].letra,"T");
      nota2[0].duracao=1/16;
    strcpy(nota2[0].letra,"X");
      nota2[0].duracao=1/64;
    for(i=0;i<strlen(compasso);i++){
      if(compasso[i]=='0'){
        printf("Obrigado");
        aux=1;
        break;
      }else if(compasso[i]==nota2[0].letra){
        soma_do_compasso+=nota2[0].duracao;
      }else if(compasso[i]==nota2[1].letra){
        soma_do_compasso+=nota2[1].duracao;
      }else if(compasso[i]==nota2[2].letra){
        soma_do_compasso+=nota2[2].duracao;
      }else if(compasso[i]==nota2[3].letra){
        soma_do_compasso+=nota2[3].duracao;
      }else if(compasso[i]==nota2[4].letra){
        soma_do_compasso+=nota2[4].duracao;
      }else if(compasso[i]==nota2[5].letra){
        soma_do_compasso+=nota2[5].duracao;
      }else if(compasso[i]==nota2[6].letra){
        soma_do_compasso+=nota2[6].duracao;
      }
    }
    if(aux==1){
      break;
    }else if(soma_do_compasso==1){
      soma_dos_certos++;
    }
    printf("%d",soma_dos_certos);
  }
  return 0;
}