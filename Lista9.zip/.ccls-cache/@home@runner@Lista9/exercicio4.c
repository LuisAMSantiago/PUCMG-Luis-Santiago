/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
char modelo[15];
float consumo;
}carro;

void compara_carros(int N, carro *modelo){
  int i,z;
  char mais_economico[15];
  strcpy(mais_economico,modelo[z].modelo);
  while(N>0){
    if(N==1){
      printf("\n%s",mais_economico);
    }else{ 
      for(z=0;z<N;z++){
        if(modelo[z].consumo>modelo[z+1].consumo){
          strcpy(modelo[z+1].modelo,modelo[z].modelo);
          modelo[z+1].consumo=modelo[z].consumo;
          strcpy(mais_economico,modelo[z+1].modelo);
        }
      }
    }
    N--;
  }
}

int main(){
  int N,a,b;
  carro modelo[15];

  printf("Insira quantos carros você pretende comparar:\n");
  scanf("%d",&N);
  for(a=0;a<N;a++){
    printf("Insira o modelo do %d° carro:\n",(a+1));
    scanf("%s",modelo[a].modelo);
    printf("Insira o consumo do %d° carro (quantos km o carro faz por litro):\n",(a+1));
    scanf("%f",&modelo[a].consumo);
  }
  compara_carros(N,modelo);
  return 0;
}
*/