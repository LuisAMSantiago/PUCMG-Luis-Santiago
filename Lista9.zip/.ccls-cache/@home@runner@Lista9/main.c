#include <stdio.h>
#include <stdlib.h>

typedef struct {
  char nome[30];
  float pot;
  float tempo;
} ele;

int main(void) {
  ele *e;
  int N = 0, i, j;
  float consumot = 0, consumor = 0, consumor2 = 0, *consumos;
  printf("Insira o número de eletrodomésticos da sua casa:\n");
  scanf("%d", &N);
  consumos = (float *)malloc(N * sizeof(float));
  e = (ele *)malloc(N * sizeof(ele));
  if (e != NULL) {
    for (i = 0; i < N; i++) {
      printf("Insira o nome do eletrodoméstico %d\n", (i + 1));
      scanf("%s", e[i].nome);
      printf("Insira a potência do elestrodoméstico %d\n", (i + 1));
      scanf("%f", &e[i].pot);
      printf("Insira o tempo de uso diário (em horas) do eletrodoméstico %d\n",
             (i + 1));
      scanf("%f", &e[i].tempo);
      consumot += (e[i].pot * e[i].tempo * 30);
    }
    printf("\nSeu consumo total mensal é de %.2f\n\n", consumot);
    for (i = 0; i < N; i++) {
      consumor = (e[i].pot * e[i].tempo * 30);
      consumor = (consumor * 100) / consumot;
      consumos[i] = consumor;
      printf("O consumo do eletrodoméstico '%s' é de %.2f\n", e[i].nome,
             consumos[i]);
    }
  }
  return 0;
}