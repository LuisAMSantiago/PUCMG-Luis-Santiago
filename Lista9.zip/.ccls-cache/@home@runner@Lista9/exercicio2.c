/*
#include <stdio.h>
#include <stdlib.h>

enum dias_da_semana {domingo,segunda,terça,quarta,quinta,sexta,sábado};

int main(){
  int i;
  char **matriz,dia;
  printf("Insira um dia da semana:\n");
  scanf("%s",&dia);
  matriz=(char**)malloc(7*sizeof(char*));
  for(i=0;i<7;i++){
    matriz[i]=(char*)calloc(strlen(),sizeof(char));
    
  }
  return 0;
}
*/