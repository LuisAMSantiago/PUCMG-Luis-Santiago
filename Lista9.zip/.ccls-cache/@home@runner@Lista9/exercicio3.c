/*
#include <stdio.h>
#include <stdlib.h>

enum meses{janeiro,fevereiro,março,abril,maio,junho,julho,agosto,setembro,outubro,novembro,dezembro};

typedef struct{
  int dia;
  int mes;
  int ano;
}data;

typedef struct{
  int horas;
  int minutos;
  int segundos;
}hora;

typedef struct{
  int data;
  int hora;
  char descricao[99];
}compromisso;

void registra(){
  
}

int main() {
  int opcao,opcao2,i,**matriz;
        printf("Olá! Seja bem-vindo ao MySecretary! Para continuar, selecione uma das opções abaixo:\n__________________________________________________\n\n 1. Registrar compromisso\n 2. Listar todos os compromissos\n 3. Listar compromissos de um mês específico\n 0. Sair\n__________________________________________________\n\n");
  scanf("%d", &opcao);
  matriz=(int**)malloc(12*sizeof(int*));
  while (1) {
    if (opcao == 0) {
      break;
    }
    else if (opcao == 1) {
      printf("Você selecionou 'Registrar compromisso'. Insira agora a data e a hora do compromisso:(ex: dia 30 às 14:00 ficaria: 30 1400)");
      scanf("%d %d");
      for(i=0;i<12;i++){
        if(opcao2==0){
        break;
          }
        matriz[i]=(int*)calloc(30,sizeof(int));
        
      }
    }
    if (opcao == 2) {
      printf("o programador é um $@#*&#& e ainda não programou isso\n\n");
    }
    if (opcao == 3) {
      printf("o programador é um $@#*&#& e ainda não programou isso\n\n");
    }
    printf("\n 1. Registrar compromisso\n 2. Listar todos os compromissos\n 3. Listar compromissos de um mês específico\n 0. Sair\n__________________________________________________\n\n");
    scanf("%d", &opcao);
  }
  return 0;
}
*/